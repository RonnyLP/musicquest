package com.example.melodyquest.core.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.melodyquest.feature.home.ui.HomeScreen
import com.example.melodyquest.feature.login.ui.LoginScreen
import com.example.melodyquest.feature.trackplayer.ui.TrackPlayerScreen

@Composable
fun AppNavHost(
    navController: NavHostController,
    startDestination: String = Screen.Login.route
) {

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable (Screen.Login.route) {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate(Screen.Home.route)
                }
            )
        }
        composable(Screen.Home.route) {
            HomeScreen(
                onNavigateToPlayer = {
                    navController.navigate(Screen.Player.route)
                }
            )
        }
        composable(Screen.Player.route) {
//            val viewModel = hiltViewModel()
            TrackPlayerScreen(
                onNavigateBack = {
                    navController.navigate(Screen.Home.route)
                }
            )
        }

    }

}