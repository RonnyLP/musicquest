package com.example.melodyquest.core.ui.icons

object AppIcons
