package com.example.melodyquest.feature.login.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.melodyquest.core.ui.components.GreenButton
import com.example.melodyquest.core.ui.components.TransparentButton
import com.example.melodyquest.feature.login.viewmodel.LoginViewModel


@Preview
@Composable
fun LoginScreenPreview() {
    LoginScreen(onLoginSuccess = {})
}

@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit,
    viewModel: LoginViewModel = viewModel()
) {
    Column(
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(32.dp)
    ) {
        Column(
            modifier = Modifier
                .weight(1f),
            verticalArrangement = Arrangement.Center,
//            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("MusicQuest", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        }

        Column(
        ) {

        }
        GreenButton(
            onClick = {
                viewModel.loginWithGoogle(onSuccess = onLoginSuccess)
            },
            text = "Iniciar sesión con Google",
            modifier = Modifier
                .fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        TransparentButton(
            onClick = {
                viewModel.loginAsGuest(onSuccess = onLoginSuccess)
            },
            text = "Iniciar sesión como invitado",
            modifier = Modifier
                .fillMaxWidth()
        )
    }
}

//@Composable
//fun LoginScreen(
//    onLoginSuccess: () -> Unit
//) {
//    Column(
//        verticalArrangement = Arrangement.SpaceBetween,
//        horizontalAlignment = Alignment.CenterHorizontally,
//        modifier = Modifier
//            .fillMaxSize()
//            .background(Color.White)
//            .padding(32.dp)
//    ) {
//        Column(
//            modifier = Modifier
//                .weight(1f),
//            verticalArrangement = Arrangement.Center,
//        ) {
//            Text("MusicQuest", fontSize = 32.sp, fontWeight = FontWeight.Bold)
//        }
//
//        GreenButton(
//            onClick = {
//                onLoginSuccess()
//            },
//            text = "Iniciar sesión con Google",
//            modifier = Modifier
//                .fillMaxWidth()
//        )
//        Spacer(modifier = Modifier.height(16.dp))
//        TransparentButton(
//            onClick = {
//
//            },
//            text = "Iniciar sesión como invitado",
//            modifier = Modifier
//                .fillMaxWidth()
//        )
//    }
//}