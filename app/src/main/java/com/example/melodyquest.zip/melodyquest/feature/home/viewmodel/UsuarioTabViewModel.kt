package com.example.melodyquest.feature.home.viewmodel

import androidx.lifecycle.ViewModel

class UsuarioTabViewModel: ViewModel() {



    fun startGoogleAuth() {
        // Código aquí
    }

}