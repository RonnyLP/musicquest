package com.example.melodyquest.core.theme

import androidx.compose.ui.graphics.Color

val Green500 = Color(0xFF2F9E44)

val Gray500 = Color(0xFFBBBFC4)

val Red500 = Color(0xFFE03131)

