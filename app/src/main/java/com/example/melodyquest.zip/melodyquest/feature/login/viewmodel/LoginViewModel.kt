package com.example.melodyquest.feature.login.viewmodel

import androidx.lifecycle.ViewModel

class LoginViewModel: ViewModel() {

    fun loginAsGuest(onSuccess: () -> Unit) {
        // Lógica para iniciar sesión como invitado
        onSuccess()
    }

    fun loginWithGoogle(onSuccess: () -> Unit) {
        // Lógica para iniciar sesión con Google
        onSuccess()
    }


}